<div>
    <div class="flex items-center gap-4">
        <p class="shimmer h-[21px] w-[55px]"></p>

        <p class="shimmer h-[21px] w-20"></p>
    </div>

    <!-- Price range slider effect -->
    <div class="relative mx-auto flex h-20 w-full items-center justify-center p-2">
        <div class="shimmer relative h-1 w-full rounded-2xl bg-gray-200"></div>
    </div>
</div>
