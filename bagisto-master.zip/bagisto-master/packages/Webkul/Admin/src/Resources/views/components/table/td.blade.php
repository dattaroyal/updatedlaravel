<td {{ $attributes->merge(['scope' => 'row', 'class' => 'whitespace-nowrap px-6 py-4 text-gray-600']) }}>
    {{ $slot }}
</td>
